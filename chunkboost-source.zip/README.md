# Chunk Boost (Fabric 1.20.1)
Mod de cliente. Necesita Fabric API. Mod Menu opcional (para el boton Config).
Compilar: sube todo a GitHub -> Actions -> build -> descarga el artifact "chunkboost-jar".
