package com.chunkboost;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ChunkBoostMod implements ClientModInitializer {
    public static final Logger LOGGER = LoggerFactory.getLogger("chunkboost");

    private static int frames = 0;
    private static long windowStart = System.nanoTime();
    private static long lastChange = System.nanoTime();
    private static double avgFps = -1;
    private static int current = 12;
    private static boolean pendingApply = true;

    @Override
    public void onInitializeClient() {
        ChunkBoostConfig.load();
        WorldRenderEvents.START.register(ctx -> frames++);
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> pendingApply = true);
        ClientTickEvents.END_CLIENT_TICK.register(ChunkBoostMod::tick);
    }

    /** La pantalla de config lo llama al guardar. */
    public static void requestApply() {
        pendingApply = true;
    }

    private static void tick(MinecraftClient client) {
        ChunkBoostConfig cfg = ChunkBoostConfig.INSTANCE;
        if (client.world == null || client.player == null || !cfg.enabled) {
            return;
        }
        long now = System.nanoTime();

        if (pendingApply) {
            pendingApply = false;
            applyExtras(client, cfg);
            if (cfg.adaptive) {
                int start = client.options.getViewDistance().getValue();
                setChunks(client, Math.max(cfg.minChunks, Math.min(cfg.maxChunks, start)));
            } else {
                setChunks(client, cfg.chunks);
            }
            frames = 0;
            windowStart = now;
            return;
        }

        if (!cfg.adaptive) return;

        // Solo medimos FPS jugando (sin menus abiertos)
        if (client.currentScreen != null) {
            frames = 0;
            windowStart = now;
            return;
        }

        long elapsed = now - windowStart;
        if (elapsed < 1_000_000_000L) return;

        double fps = frames * 1_000_000_000.0 / elapsed;
        frames = 0;
        windowStart = now;
        avgFps = avgFps < 0 ? fps : avgFps * 0.6 + fps * 0.4;

        double sinceChange = (now - lastChange) / 1_000_000_000.0;

        if (avgFps < cfg.targetFps && current > cfg.minChunks && sinceChange >= 6) {
            setChunks(client, Math.max(cfg.minChunks, current - 2)); // bajar rapido
        } else if (avgFps > cfg.targetFps * 1.3 && current < cfg.maxChunks && sinceChange >= 15) {
            setChunks(client, current + 1); // subir despacio, sin tirones
        }
    }

    private static void setChunks(MinecraftClient client, int value) {
        value = Math.max(2, Math.min(32, value));
        current = value;
        lastChange = System.nanoTime();
        avgFps = -1;
        var opt = client.options.getViewDistance();
        if (opt.getValue().intValue() != value) {
            opt.setValue(value);
            client.options.write();
        }
    }

    private static void applyExtras(MinecraftClient client, ChunkBoostConfig cfg) {
        if (!cfg.saver) return;

        var sim = client.options.getSimulationDistance();
        if (sim.getValue().intValue() != cfg.simulationDistance) {
            sim.setValue(cfg.simulationDistance);
        }

        var ent = client.options.getEntityDistanceScaling();
        double scale = cfg.entityPercent / 100.0;
        if (Math.abs(ent.getValue().doubleValue() - scale) > 0.001) {
            ent.setValue(scale);
        }

        var blend = client.options.getBiomeBlendRadius();
        if (blend.getValue().intValue() != cfg.biomeBlend) {
            blend.setValue(cfg.biomeBlend);
        }
    }
}
