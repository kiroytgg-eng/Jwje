package com.chunkboost;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;

import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.IntConsumer;

public class ConfigScreen extends Screen {
    private final Screen parent;
    private final ChunkBoostConfig cfg = ChunkBoostConfig.INSTANCE;

    public ConfigScreen(Screen parent) {
        super(Text.literal("Chunk Boost"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int w = Math.min(200, (this.width - 30) / 2);
        int xl = this.width / 2 - w - 4;
        int xr = this.width / 2 + 4;
        int y0 = 38;
        int step = 22;

        // Columna izquierda
        addDrawableChild(toggle(xl, y0, w, "Activado", () -> cfg.enabled, v -> cfg.enabled = v));
        addDrawableChild(toggle(xl, y0 + step, w, "Adaptativo", () -> cfg.adaptive, v -> cfg.adaptive = v));
        addDrawableChild(new IntSlider(xl, y0 + step * 2, w, "Chunks fijos", 2, 32, 1, cfg.chunks, v -> cfg.chunks = v));
        addDrawableChild(new IntSlider(xl, y0 + step * 3, w, "Chunks min", 2, 32, 1, cfg.minChunks, v -> cfg.minChunks = v));
        addDrawableChild(new IntSlider(xl, y0 + step * 4, w, "Chunks max", 2, 32, 1, cfg.maxChunks, v -> cfg.maxChunks = v));

        // Columna derecha
        addDrawableChild(new IntSlider(xr, y0, w, "FPS objetivo", 15, 240, 5, cfg.targetFps, v -> cfg.targetFps = v));
        addDrawableChild(toggle(xr, y0 + step, w, "Ahorro extra", () -> cfg.saver, v -> cfg.saver = v));
        addDrawableChild(new IntSlider(xr, y0 + step * 2, w, "Simulacion", 5, 32, 1, cfg.simulationDistance, v -> cfg.simulationDistance = v));
        addDrawableChild(new IntSlider(xr, y0 + step * 3, w, "Entidades %", 50, 200, 25, cfg.entityPercent, v -> cfg.entityPercent = v));
        addDrawableChild(new IntSlider(xr, y0 + step * 4, w, "Mezcla biomas", 0, 7, 1, cfg.biomeBlend, v -> cfg.biomeBlend = v));

        addDrawableChild(ButtonWidget.builder(Text.literal("Listo"), b -> this.close())
                .dimensions(this.width / 2 - 100, this.height - 27, 200, 20).build());
    }

    private ButtonWidget toggle(int x, int y, int w, String label, BooleanSupplier get, Consumer<Boolean> set) {
        return ButtonWidget.builder(toggleText(label, get.getAsBoolean()), b -> {
            set.accept(!get.getAsBoolean());
            b.setMessage(toggleText(label, get.getAsBoolean()));
        }).dimensions(x, y, w, 20).build();
    }

    private static Text toggleText(String label, boolean on) {
        return Text.literal(label + ": " + (on ? "SI" : "NO"));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context);
        context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 12, 0xFFFFFF);
        context.drawCenteredTextWithShadow(this.textRenderer,
                Text.literal("Adaptativo: sube/baja los chunks segun tus FPS"), this.width / 2, 25, 0xAAAAAA);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public void removed() {
        ChunkBoostConfig.save();
        ChunkBoostMod.requestApply();
    }

    @Override
    public void close() {
        if (this.client != null) this.client.setScreen(parent);
    }

    private static class IntSlider extends SliderWidget {
        private final String label;
        private final int min, max, stepSize;
        private final IntConsumer onChange;

        IntSlider(int x, int y, int w, String label, int min, int max, int stepSize, int start, IntConsumer onChange) {
            super(x, y, w, 20, Text.empty(), (double) (Math.max(min, Math.min(max, start)) - min) / (max - min));
            this.label = label;
            this.min = min;
            this.max = max;
            this.stepSize = stepSize;
            this.onChange = onChange;
            this.updateMessage();
        }

        private int currentValue() {
            int v = min + (int) Math.round(this.value * (max - min) / stepSize) * stepSize;
            return Math.max(min, Math.min(max, v));
        }

        @Override
        protected void updateMessage() {
            this.setMessage(Text.literal(label + ": " + currentValue()));
        }

        @Override
        protected void applyValue() {
            onChange.accept(currentValue());
        }
    }
}
