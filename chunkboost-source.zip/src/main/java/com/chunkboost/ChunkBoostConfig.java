package com.chunkboost;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

public class ChunkBoostConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("chunkboost.json");

    public static ChunkBoostConfig INSTANCE = new ChunkBoostConfig();

    public boolean enabled = true;
    public boolean adaptive = true;
    public int chunks = 16;          // modo fijo
    public int minChunks = 8;        // modo adaptativo
    public int maxChunks = 32;       // modo adaptativo
    public int targetFps = 40;       // FPS que quieres mantener
    public boolean saver = true;     // ahorro extra
    public int simulationDistance = 6;
    public int entityPercent = 100;  // 50..200 en pasos de 25
    public int biomeBlend = 1;       // 0..7

    public static void load() {
        try {
            if (Files.exists(FILE)) {
                ChunkBoostConfig c = GSON.fromJson(Files.readString(FILE), ChunkBoostConfig.class);
                if (c != null) INSTANCE = c;
            }
        } catch (Exception e) {
            ChunkBoostMod.LOGGER.error("No se pudo leer la config de Chunk Boost", e);
        }
        INSTANCE.clamp();
        save();
    }

    public static void save() {
        try {
            INSTANCE.clamp();
            Files.writeString(FILE, GSON.toJson(INSTANCE));
        } catch (Exception e) {
            ChunkBoostMod.LOGGER.error("No se pudo guardar la config de Chunk Boost", e);
        }
    }

    public void clamp() {
        chunks = Math.max(2, Math.min(32, chunks));
        minChunks = Math.max(2, Math.min(32, minChunks));
        maxChunks = Math.max(2, Math.min(32, maxChunks));
        if (maxChunks < minChunks) maxChunks = minChunks;
        targetFps = Math.max(15, Math.min(240, targetFps));
        simulationDistance = Math.max(5, Math.min(32, simulationDistance));
        entityPercent = Math.max(50, Math.min(200, entityPercent));
        biomeBlend = Math.max(0, Math.min(7, biomeBlend));
    }
}
